var files_dup =
[
    [ "Circle.h", "_circle_8h_source.html", null ],
    [ "DOxygenMainProjectPage.h", "_d_oxygen_main_project_page_8h_source.html", null ],
    [ "Shape.h", "_shape_8h_source.html", null ],
    [ "Square.h", "_square_8h_source.html", null ]
];