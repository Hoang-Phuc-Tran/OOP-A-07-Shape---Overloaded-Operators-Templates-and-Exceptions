var hierarchy =
[
    [ "Shape", "class_shape.html", [
      [ "Circle", "class_circle.html", null ],
      [ "Square", "class_square.html", null ]
    ] ]
];