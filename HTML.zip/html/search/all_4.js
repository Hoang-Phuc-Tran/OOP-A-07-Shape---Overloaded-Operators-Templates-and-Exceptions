var searchData=
[
  ['name_0',['name',['../class_shape.html#afef5e9426226fd7af49fe48ec16b97f3',1,'Shape']]],
  ['name_5fvalid_1',['NAME_VALID',['../class_shape.html#a5867cd7856d68a91e371486e619315fe',1,'Shape']]],
  ['not_5fvalid_2',['NOT_VALID',['../class_shape.html#a661bb87065eea86546e0cb63dcf002db',1,'Shape']]]
];
