var searchData=
[
  ['max_5flength_5fcolour_0',['MAX_LENGTH_COLOUR',['../class_shape.html#aa6ed206be951ba876bdc1ad12504d35d',1,'Shape']]],
  ['max_5flength_5fname_1',['MAX_LENGTH_NAME',['../class_shape.html#a8dc597e71dcfeea1be97393459c98bec',1,'Shape']]]
];
